---
title: toulel
emoji: 🐳
colorFrom: green
colorTo: red
sdk: static
pinned: false
tags:
  - deepsite
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference